plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.xplay.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.xplay.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-age-of-kings"
    }
}


dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
}
