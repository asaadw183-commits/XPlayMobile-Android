package com.xplay.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 19, 31)
    private val panel = Color.rgb(30, 36, 56)
    private val purple = Color.rgb(154, 123, 255)
    private lateinit var status: TextView
    private lateinit var selectedFile: TextView
    private var lowGraphics = true

    private val pickGameRequest = 1002

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickGameRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val folder = DocumentFile.fromTreeUri(this, uri)
            val exe = folder?.listFiles()?.firstOrNull { it.isFile && it.name.equals("empires2.exe", ignoreCase = true) }
            selectedFile.text = if (exe != null) {
                "تم العثور على ملف اللعبة: empires2.exe\nالمجلد: ${folder?.name ?: "مجلد اللعبة"}"
            } else {
                "تم اختيار المجلد، لكن لم نعثر على empires2.exe في مستواه الرئيسي. اختر مجلد اللعبة الصحيح."
            }
            status.text = if (exe != null) "تم التعرف على نسخة Age of Empires II: The Age of Kings. محرك التشغيل Winlator غير مدمج داخل التطبيق؛ شغّل اللعبة من بيئة Winlator بعد إعدادها." else "لم يتم تأكيد ملف تشغيل اللعبة بعد."
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "🎮"
            textSize = 27f
            gravity = Gravity.CENTER
            background = rounded(purple, 18)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        header.addView(logo)
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleBox.addView(label("XPlay Mobile", 24f, Color.WHITE, true))
        titleBox.addView(label("PC Gaming Emulator · Android", 12f, 0xFFB8BED0.toInt()))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(pill("PROTOTYPE", purple))
        root.addView(header)
        gap(root, 24)

        root.addView(section("لوحة التحكم"))
        gap(root, 10)
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("وضع التشغيل", "محلي"), LinearLayout.LayoutParams(0, dp(88), 1f))
        stats.addView(space(10), LinearLayout.LayoutParams(dp(10), 1))
        stats.addView(statCard("الذاكرة المستهدفة", "3–4 GB"), LinearLayout.LayoutParams(0, dp(88), 1f))
        root.addView(stats)
        gap(root, 24)

        root.addView(section("مكتبة الألعاب"))
        gap(root, 10)
        val gameCard = card()
        gameCard.orientation = LinearLayout.VERTICAL
        gameCard.addView(label("📂  اختر مجلد Age of Empires II", 17f, Color.WHITE, true))
        gap(gameCard, 6)
        gameCard.addView(label("اختر المجلد الذي يحتوي على empires2.exe. سيتحقق التطبيق من وجود ملف تشغيل نسخة The Age of Kings.", 13f, 0xFFBEC5D9.toInt()))
        gap(gameCard, 14)
        val choose = button("اختيار مجلد اللعبة")
        choose.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, pickGameRequest)
        }
        gameCard.addView(choose)
        gap(gameCard, 8)
        selectedFile = label("لم يتم اختيار مجلد اللعبة", 12f, 0xFFB8BED0.toInt())
        gameCard.addView(selectedFile)
        root.addView(gameCard)
        gap(root, 22)

        root.addView(section("إعدادات الأداء"))
        gap(root, 10)
        val settings = card()
        settings.orientation = LinearLayout.VERTICAL
        settings.addView(label("وضع الرسوميات", 16f, Color.WHITE, true))
        gap(settings, 8)
        val graphics = Switch(this).apply {
            text = "رسوميات منخفضة (مناسب كبداية)"
            setTextColor(Color.WHITE)
            isChecked = true
            setOnCheckedChangeListener { _, checked ->
                lowGraphics = checked
                status.text = if (checked) "تم اختيار إعداد الرسوميات المنخفضة." else "تم اختيار إعداد الرسوميات العادية."
            }
        }
        settings.addView(graphics)
        gap(settings, 8)
        settings.addView(label("ملاحظة: الإعداد حاليًا تجريبي ولا يغيّر أداء لعبة فعلية.", 12f, 0xFFBEC5D9.toInt()))
        root.addView(settings)
        gap(root, 22)

        root.addView(section("حالة المحرك"))
        gap(root, 10)
        val statusCard = card()
        statusCard.orientation = LinearLayout.VERTICAL
        status = label("الواجهة جاهزة. محرك تشغيل Windows غير مدمج بعد.", 14f, Color.WHITE)
        statusCard.addView(status)
        gap(statusCard, 8)
        statusCard.addView(label("التطبيق يتحقق من مجلد اللعبة فقط. يلزم إعداد Winlator بشكل منفصل؛ لا يوجد محرك Windows مدمج في هذا الإصدار.", 12f, 0xFFBEC5D9.toInt()))
        root.addView(statusCard)
        gap(root, 24)

        val footer = label("XPlay Mobile  •  Age of Kings  •  الإصدار 0.2 تجريبي", 11f, 0xFF8F98B0.toInt())
        footer.gravity = Gravity.CENTER
        root.addView(footer)
    }

    private fun section(text: String) = label(text, 19f, Color.WHITE, true)

    private fun statCard(caption: String, value: String): LinearLayout {
        val box = card()
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.addView(label(caption, 12f, 0xFFB8BED0.toInt()))
        gap(box, 6)
        box.addView(label(value, 20f, Color.WHITE, true))
        return box
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, 18)
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(purple, 14)
        minHeight = dp(48)
    }

    private fun pill(text: String, color: Int) = TextView(this).apply {
        this.text = text
        textSize = 10f
        setTextColor(Color.WHITE)
        setPadding(dp(9), dp(7), dp(9), dp(7))
        background = rounded(color, 20)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun gap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun space(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
